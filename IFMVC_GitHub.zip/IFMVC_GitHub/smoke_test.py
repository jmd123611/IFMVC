import numpy as np
import torch

from network import Network
from post_tree import compute_partition_medians, tree_fusion


def main():
    device = torch.device("cpu")
    model = Network(2, [2, 2], 8, 4, 3, device).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-4)
    assert optimizer.param_groups[0]["lr"] == 1e-4

    labels = np.repeat(np.arange(3), 4)
    view1 = np.column_stack((labels * 10.0, np.arange(12, dtype=float)))
    view2 = np.column_stack((labels * 20.0, np.arange(12, dtype=float) * 0.5))
    label_matrix = np.column_stack((labels, labels))

    medians = compute_partition_medians(view1, labels, 3)
    for cluster in range(3):
        expected = np.median(view1[labels == cluster], axis=0)
        assert np.array_equal(medians[cluster], expected)

    _, predictions, centers = tree_fusion(label_matrix, [view1, view2], 3)
    assert predictions.shape == (12,)
    assert centers.shape == (3, 4)
    print("SMOKE TEST PASSED")
    print("optimizer learning rate: 0.0001")
    print("Algorithm 2 entered tree construction with coordinate-wise median centers")


if __name__ == "__main__":
    main()
