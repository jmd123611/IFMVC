# Mfeat data

Place the Mfeat MATLAB file here as:

```text
data/mfeat.mat
```

The file must contain six arrays named `X1`, `X2`, `X3`, `X4`, `X5`, and `X6`.
The expected view dimensions are 216, 76, 64, 6, 240, and 47, with 2,000 samples per view.
